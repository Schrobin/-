	var arrays = ["images/banner.jpg","images/banner1.jpg","images/banner2.jpg"]; 
	var i =0;
	function changeBanner(){
		if(i>=arrays.length){
			i = 0;
		}
		document.getElementById("img").src=arrays[i];
		changeBtn(i);
		i++;
		setTimeout("changeBanner()",1000);
	}

	function changeBtn(current){
		for(var i=0;i<arrays.length;i++){
			if(i==current){
				document.getElementById(""+current).src="images/banner-btn1 .png";
			}else{
				document.getElementById(""+i).src="images/banner-btn .png";
			}
		}
	}

	var arrays2 = ["../images/banner.jpg","../images/banner1.jpg","../images/banner2.jpg"]; 
	var j =0;
	function changeBanner2(){
		if(j>=arrays2.length){
			j = 0;
		}
		document.getElementById("img").src=arrays2[j];
		changeBtn2(j);
		j++;
		setTimeout("changeBanner2()",1000);
	}
	function changeBtn2(current){
		for(var i=0;i<arrays2.length;i++){
			if(i==current){
				document.getElementById(""+current).src="../images/banner-btn1 .png";
			}else{
				document.getElementById(""+i).src="../images/banner-btn .png";
			}
		}
	}
