/**
 * jqGrid的扩展，依赖commons.js文件中对jquery的扩展方法$.wrap
 * @charset utf8
 * @autor liujhc
 */
(function($){
    var isGridOptions=function(o){//返回参数是否为jgGrid的配置
        return o && typeof o == 'object' && 'colModel' in o;
    }
    /**
     * jqGrid Bug补丁
     */
    $.fn.jqGrid=$.wrap($.fn.jqGrid,function(o){
        if(!isGridOptions(o)) return;
        //当reload时清除选择
        o.loadComplete=$.wrap(o.loadComplete,function(){
            this.p.selarrrow=[];
            this.p.selrow=null;
        });
    });
    /**
     * zebra 斑马线
     * 当使用树形表格treeGrid功能，斑马线功能将不被启用
     */
    $.fn.jqGrid=$.wrap($.fn.jqGrid,function(o){
        if(!isGridOptions(o) || o.zebra==false || o.treeGrid) return;
        var zebra=function($tr){
            $tr.addClass("list-odd").hover(function(){
                $(this).removeClass("list-odd");
            }, function(){
                if($(this).attr("aria-selected")!="true"){
                    $(this).addClass("list-odd");
                }
            });
        }
        var $table=this, rownum=0;
        o.afterInsertRow=$.wrap(o.afterInsertRow,function(){
            if((++rownum)%2==0){
                zebra($table.find("tr:eq("+rownum+")"));
            }
        });
        o.onSelectAll=$.wrap(o.onSelectAll,function(rowIds, checked){
            if(checked){
                $table.find("tr.jqgrow").removeClass("list-odd");
            }else{
                zebra($table.find("tr.jqgrow:odd"));
            }
        });
        o.gridComplete = $.wrap(o.gridComplete, function () {
            zebra($table.find("tr.jqgrow:odd"));
            rownum = 0;
        });
    });

    /**
     * 允许设置表格的最小高度
     * @type {*}
     */
    $.fn.jqGrid = $.wrap($.fn.jqGrid, null, function (o) {
        if (!isGridOptions(o)) return;
        $(".ui-jqgrid-bdiv", "#gbox_" + this.get(0).id).css("min-height", o.minHeight || 'auto');
    });

    /**
     * 记录最后一次pageSize的调整
     * @type {*}
     */
    (function () {
        $.fn.jqGrid = $.wrap($.fn.jqGrid, function (o) {
            if (!isGridOptions(o)) return;
            o.rowNum = store.get(PAGE_SIZE_STORE_KEY(o)) || o.rowNum;
        }, function (o) {
            if (!isGridOptions(o)) return;
            $('.ui-pg-selbox', this[0].p.pager).change(function () {
                store.set(PAGE_SIZE_STORE_KEY(o), $(this).val());
            });
        });
        function PAGE_SIZE_STORE_KEY(o) {
            return location.pathname + o.pager + ":pageSize";
        }
    })();

    /**
     * 自适应宽度
     */
    $.fn.jqGrid = $.wrap($.fn.jqGrid, function (o) {
        if (!isGridOptions(o)) return;
        var $table = this;
        var t = this.get(0);
        if (o.autowidth !== true) { // 不自动适应窗口(显示滚动条)
            $(window).resize(function () {
                $('#gview_' + t.p.id).children().andSelf().add('#gbox_' + t.p.id + ',' + t.p.pager)
                    .width($table.parents(".ui-jqgrid").parent().width() - 2);
            });
            o.resizeStop = $.wrap(o.resizeStop, function (width, index) {
                // 记录下对宽度的调整
                saveWidthSetting($table[0].p.colModel[index].name, width);
            });

            o.gridComplete = $.wrap(o.gridComplete, null, function () {
                // 当没有数据时也需要能够滚动列
                $table.find('tr.jqgfirstrow').height($table.jqGrid("getDataIDs").length > 0 ? 0 : 1);
            });

            var COL_WIDTH_SETTING_KEY = location.pathname + '#' + $table.attr('id') + '_colModel#width';

            var widthSettings = getWidthSettings();
            $.each(o.colModel, function () {
                this.width = widthSettings[this.name] || this.width;
            });

            function getWidthSettings() {
                var json = store.get(COL_WIDTH_SETTING_KEY);
                return json ? JSON.parse(json) : {};
            }

            function saveWidthSetting(colName, width) {
                var setting = getWidthSettings();
                setting[colName] = width;
                store.set(COL_WIDTH_SETTING_KEY, JSON.stringify(setting));
            }

            $table.data('COL_WIDTH_SETTING_KEY', COL_WIDTH_SETTING_KEY);
        } else { // 自适应窗口大小
            var treeResizing = false;
            o.resizeStart = $.wrap(o.resizeStart, function () {//在调整列宽的时候不进行整个表格的宽度重置
                treeResizing = true;
            });
            o.resizeStop = $.wrap(o.resizeStop, function () {
                setTimeout(function () {
                    treeResizing = false;
                }, 100);
            });
            $(window).resize(function () {//在窗口大小改变时，重置jqGrid的宽度
                if (!treeResizing) {
                    treeResizing = true;
                    setTimeout(function () {
                        $table.setGridWidth($table.parents(".ui-jqgrid").parent().width() - 2);
                        treeResizing = false;
                    }, 100);
                }
            });
        }
        o.loadComplete = $.wrap(o.loadComplete, function () {
            $(window).triggerHandler('resize');
        });
    }, function () {
        // 表格初始化之后重置大小
        $(window).triggerHandler('resize');
    });

    /**
     * 活动列(调整列的显示与隐藏以及列之间的显示顺序)
    */
    $.fn.jqGrid=$.wrap($.fn.jqGrid,null,function(o){
        if(!isGridOptions(o) || !o.pager || !o.columnChooser) return;
        $.extend($.jgrid.nav,{//禁止表格左下角的其他按钮的显示
            edit:false,
            add:false,
            del:false,
            search:false,
            refresh: false
        });
        var ts=$(this).get(0),
        tid=ts.p.id+'_';
        function remapColumns(th,colModel){
            var cmMap = {};
            $.each(colModel, function(i) {
                cmMap[this.name]=i;
            });
            var permutation = [];
            th.each(function(i) {
                var id = $(">div", this).get(0).id.replace(/^jqgh_/, "").replace(tid,"");
                if (id in cmMap) {
                    permutation.push(cmMap[id]);
                }
            });
            $(ts).jqGrid("remapColumns",permutation, true, true);
        }
        function encodeColModel(colModel){
            var result="",max=colModel.length-1;
            for(var i=0;;i++){
                result+=colModel[i].name+'/'+(colModel[i].hidden?0:1);
                if(i==max){
                    return result;
                }else{
                    result+='#';
                }
            }
        }
        function decodeColModel(str){
            if(!str) return null;
            var result=[],arr=(str||'').split('#'),max=arr.length-1;
            for(var i=0; ;i++){
                var a=arr[i].split('/');
                result.push({
                    name:a[0],
                    hidden:!parseInt(a[1])
                });
                if(i==max){
                    return result;
                }
            }
        }
        var colsId=tid+'cols',
        COL_SETTING_KEY=location.pathname+'#'+tid+'colModel',
        ulCss={
            listStyleType: 'none',
            margin: 0,
            padding: 5,
            'float': 'left',
            background: '#E5E5E5',
            width: 143
        },
        liCss={
            margin: 5,
            padding: 5,
            fontSize: 12,
            width: 120,
            cursor:'pointer'
        };
        $('<div id="'+colsId+'"/>')
        .append('<ul class="visible"/>')
        .append('<ul class="hidden"/>')
        .insertAfter(this).hide().find("ul").css(ulCss);
        this.navGrid(o.pager).navButtonAdd(o.pager,{
            id: tid + 'colsActive',
            caption:'调整列',
            title:'调整显示列',
            buttonicon:'ui-icon-wrench',
            onClickButton:function(){
                var $hidden = $("#"+colsId+'>ul.hidden'),
                $visible = $("#"+colsId+'>ul.visible');
                $.each(ts.p.colModel,function(i){//生成li，供用户拖拽排序
                    $('<li/>').text(ts.p.colNames[i]).attr('sortable',this.sortable).attr('colName',this.name)[this.hidedlg?'hide':'show']()
                    .appendTo(this.hidden?$hidden:$visible).css(liCss)
                    .addClass(this.hidden?'ui-state-disabled':'ui-state-default');
                });
                $('#'+colsId).dialog({
                    title:'调整列',
                    width:330,
                    create:function(){
                        //调整窗口底部的按钮样式
                        $(this).parent().find(".ui-dialog-buttonpane button").unbind("mouseover").removeClass();
                    },
                    close:function(){
                        $hidden.empty();
                        $visible.empty();
                    },
                    buttons:{
                        "重置为系统初始状态":function(){
                            if(confirm("重置将刷新页面，您确定现在重置吗？")){
                                store.remove(COL_SETTING_KEY);
                                store.remove($(ts).data('COL_WIDTH_SETTING_KEY'));
                                window.location.reload();
                            }
                        }
                    }
                }).find('ul').sortable({
                    connectWith: "#"+colsId+">ul",
                    items: 'li:not([sortable=false])',
                    over: function(event, ui) {
                        $(ui.item).addClass('ui-state-highlight');
                    },
                    out: function(event, ui) {
                        $(ui.item).removeClass('ui-state-highlight');
                    },
                    update:function(event, ui){
                        var colName=$(ui.item).removeClass('ui-state-highlight').attr('colName'),
                        $th=$('#'+tid+colName);
                        if($(this).is('ul.visible')){
                            $(ui.item).addClass('ui-state-default').removeClass('ui-state-disabled');
                            $(ts).showCol(colName);
                            //更新排序
                            if($(ui.item).next().length==0){
                                $th.insertAfter('#'+tid+$(ui.item).prev().attr('colName'));
                            }else{
                                $th.insertBefore('#'+tid+$(ui.item).next().attr('colName'));
                            }
                            remapColumns($th.siblings().andSelf(),ts.p.colModel);
                        }else{
                            $(ui.item).addClass('ui-state-disabled').removeClass('ui-state-default');
                            $(ts).hideCol(colName);
                        }
                        setTimeout(function(){
                            store.set(COL_SETTING_KEY,encodeColModel(ts.p.colModel));//将最新字段顺序和显示状态存入本地存储
                            $(ts).trigger("reloadGrid", [{page: 1}]);
                        }, 100);
                    }
                }).disableSelection();
            }
        });
        //如果cookie中有排序的列名，恢复用户的设置
        var colModel=decodeColModel(store.get(COL_SETTING_KEY));
        var sortedNames = function (cols) {
            return $.map(cols,function (v) {
                return v.name
            }).sort().join(',');
        }
        // 只有表格中现有列于缓存时一致才使用缓存，防止列错乱
        if ($.isArray(colModel) && colModel.length > 0 && sortedNames(colModel) == sortedNames(ts.p.colModel)) {
            var colModelMap = {};
            $.each(ts.p.colModel, function () {
                colModelMap[this.name] = this;
            });
            var $parent=$('#'+tid+colModel[0].name).parent();
            $.each(colModel, function(i){
                var col = colModelMap[this.name];
                var hidden = (this.hidden || (col && col.hidden && col.hidedlg)) && !col.filterValue;
                var $th=$('#'+tid+this.name);
                if(hidden===true){
                    $(ts).hideCol(this.name);
                }else{
                    $(ts).showCol(this.name);
                }
                setTimeout(function(){
                    $th[hidden===true?'hide':'show']();
                }, 100);
                if(i!=0){
                    $th.insertAfter('#'+tid+colModel[i-1].name);
                }
            });
            remapColumns($('>th',$parent), ts.p.colModel);
        }
    });


    /**
     * 根据字典自动翻译字段值
     */
    $.fn.jqGrid = $.wrap($.fn.jqGrid, function (o) {
        if (!isGridOptions(o)) return;
        $.each(o.colModel, function () {
            if (this.dict && !this.formatter) {
                var map = {};
                var dict = typeof this.dict == 'string' ? $.getSysDict(this.dict).items : this.dict;
                $.each(dict, function () {
                    map[this.itemValue] = this.itemName;
                });
                this.formatter = function (val) {
                    return map[val] || val || '';
                }
            }
        });
    });

    /**
     * jqGrid 表头添加过滤器
     */
    $.fn.jqGrid = $.wrap($.fn.jqGrid, function (o) {
        var $this = this, t = $this.get(0), $filterRow;
        if (o == "remapColumns" && $.isArray(arguments[1])) {
            // 拦截 remapColumns, 更新列顺序调整
            $filterRow = $("#gbox_" + t.p.id + " .ui-jqgrid-htable .jq_filter_row");
            var rows = {};
            $filterRow.children().each(function (i) {
                rows[i] = this;
            });
            $.each(arguments[1], function () {
                $(rows[this]).appendTo($filterRow);
            });
        }
        if (!isGridOptions(o) || !o.filterRow) return;
        if (typeof o.filterRow != 'object') {
            o.filterRow = {}
        }
        // 显示过滤字段
        var FILTER_COMPUTE = 'compute', FILTER_RESULT = 'computeResult';

        o.filterRow.compute = function (filter) {
            var filterData = {};
            $filterRow.find('>td>:input[name]').each(function () {
                var $this = $(this);
                var name = $this.attr("name");
                var value = filter ? filter[name] : $this.val();
                var computeResult = $this.data(FILTER_RESULT);
                var compute = $this.data(FILTER_COMPUTE);
                if (computeResult) {
                    value = computeResult;
                } else if ($.isFunction(compute)) {
                    value = compute.call(this, value);
                }
                if (!value) {
                    if (!filter) {
                        $this.val('');
                    }
                } else if (typeof value == 'string' || $.isArray(value)) {
                    filterData[name] = value;
                } else {
                    $.extend(filterData, value);
                }
            });
            return filterData;
        }

        o.beforeRequest = $.wrap(o.beforeRequest, function () {
            initFilter();
            var filter = o.filterRow.compute();
            $this.getGridParam("postData").filter = filter;
            (function () {// 有查询条件的显示出对应列来
                if (t.grid.hDiv.loading) {
                    setTimeout(arguments.callee, 10);
                } else {
                    $.each(filter, function (k) {
                        $this.showCol(k);
                    });
                }
            })();
        });

        function initFilter() {
            if (!$filterRow) {
                $filterRow = $('<tr class="jq_filter_row ui-widget-content jqgrow ui-row-ltr" role="columnheader"></tr>')
                    .appendTo("#gbox_" + t.p.id + " .ui-jqgrid-htable");
                $.each(t.p.colModel, function (i, col) {
                    var $td = $('<td></td>').appendTo($filterRow).addClass('jq_filter_' + col.name)
                        .css("display", col.hidden ? 'none' : 'auto');
                    var $field;
                    if (col.name == 'cb') {
                        $td.css('text-align', 'center').removeClass('jq_filter_cb');
                        //$field = $("#cb_" + t.p.id).clone().attr('disabled', 'disabled').removeAttr('name');
                        $field = $('<span class="bnms-btn-filter" title="请填写过滤条件"></span>');
                    } else {
                        $field = $('<input type="text">').attr('name', col.index || col.name).css('text-align', col.align || 'auto');
                        // 添加查询条件
                        if (col.dict) {
                            var options = {
                                delay: 0,
                                minLength: 0,
                                source: [],
                                focus: function (event, ui) {
                                    var $elm = $(ui.item.value);
                                    $(event.target).val($elm.length == 0 ? ui.item.value : $elm.text());
                                    return false;
                                }
                            };
                            if (typeof col.dict == 'string' && col.dict in {date: 0, datetime: 0}) {
                                var formatStr = 'yyyy-MM-dd HH:mm:ss'; // Wdate的时间格式
                                var momentFormat = 'YYYY-MM-DD HH:mm:ss'; // moment的时间格式

                                function updateTitle($target, vals, defalut) {
                                    var title = '';
                                    if (vals[0]) {
                                        title += '开始时间：' + vals[0] + '\n';
                                    }
                                    if (vals[1]) {
                                        title += '结束时间：' + vals[1];
                                    }
                                    $target.attr('title', title || defalut || '');
                                }
                                switch (col.dict) {
                                    case 'date':
                                        formatStr = formatStr.split(' ')[0];
                                        momentFormat = momentFormat.split(' ')[0];
                                    case 'datetime':
                                        var dropDowns = {
                                            '全部': '',
                                            '今天': function(){return [moment().startOf("day").format(momentFormat)]},
                                            '最近15分钟': function(){return [moment().add("minutes", -15).format(momentFormat)]},
                                            '最近1小时': function(){return [moment().add("hours", -1).format(momentFormat)]},
                                            '最近6小时': function(){return [moment().add("hours", -6).format(momentFormat)]},
                                            '最近24小时': function(){return [moment().add("hours", -24).format(momentFormat)]},
                                            '最近3天': function(){return [moment().add("hours", -72).format(momentFormat)]},
                                            '本周': function(){return [moment().startOf("week").add("days", 1).format(momentFormat)]},
                                            '本月': function(){return [moment().startOf("month").format(momentFormat)]},
                                            '自定义范围': ''
                                        };
                                        options.create = function (event, ui) {
                                            $(event.target).data(FILTER_COMPUTE, function (value) {
                                                var dropDown = dropDowns[value];
                                                if (!dropDown) {
                                                    updateTitle($(this), []);
                                                    return '';
                                                } else {
                                                    var vals = $.isFunction(dropDown) ? dropDown() : dropDown;
                                                    var result = {};
                                                    result[this.name + '_BEGIN'] = vals[0];
                                                    result[this.name + '_END'] = vals[1];
                                                    return result;
                                                }
                                            });
                                        }
                                        options.source = $.map(dropDowns, function (v, k) {
                                            return k;
                                        });
                                        options.select = function (event, ui) {
                                            var $target = $(event.target);
                                            if (ui.item.value == '自定义范围') {
                                                var offset = $target.offset();
                                                offset.top += $target.height() + 10;
                                                var $timeRegion = $('<div style="width: 200px; padding: 5px" class="ui-corner-all ui-widget-content">' +
                                                    '开始时间：<input style="width: 132px; margin: 2px" class="Wdate beginTime" onfocus="WdatePicker({dateFmt:\'' + formatStr + '\',readOnly:true});"><br/>' +
                                                    '结束时间：<input style="width: 132px; margin: 2px" class="Wdate endTime" onfocus="WdatePicker({dateFmt:\'' + formatStr + '\',readOnly:true});"><br/>' +
                                                    '<button class="ok">确定</button class="cancel"><button>取消</button>' +
                                                    '</div>').appendTo('body');
                                                var compute = $target.data(FILTER_COMPUTE);
                                                var name = $target.attr('name');
                                                if ($.isFunction(compute)) {
                                                    var data = compute.call(this, $target);
                                                    $timeRegion.find('.beginTime').val(data[name + '_BEGIN'] || '');
                                                    $timeRegion.find('.endTime').val(data[name + '_END'] || '');
                                                }
                                                $timeRegion.find(':button').click(function () {
                                                    if ($(this).is('.ok')) {
                                                        var beginTime = $timeRegion.find('.beginTime').val();
                                                        var endTime = $timeRegion.find('.endTime').val();
                                                        $target.data(FILTER_RESULT, (function () {
                                                                updateTitle($target, [beginTime, endTime]);
                                                                if (!beginTime && !endTime) {
                                                                    return false;
                                                                } else {
                                                                    var result = {};
                                                                    result[name + '_BEGIN'] = beginTime;
                                                                    result[name + '_END'] = endTime;
                                                                    return result;
                                                                }
                                                            })()).val(ui.item.value ? ui.item.label : '')
                                                            .triggerHandler('change');
                                                        $target.data('usedValue', $target.val());
                                                    } else {
                                                        // 如果取消，还原文本框内容
                                                        $target.val($target.data('usedValue'));
                                                    }
                                                    $timeRegion.remove();
                                                });
                                                $target.one('blur', function () {
                                                    $(document).find('*').andSelf().not($timeRegion.find('*').andSelf()).one('click', function () {
                                                        // 如果取消，还原文本框内容
                                                        $target.val($target.data('usedValue'));
                                                        $timeRegion.remove();
                                                    });
                                                });
                                                $timeRegion.offset(offset);
                                            } else {
                                                $target.data('usedValue', $target.val()).removeData(FILTER_RESULT).triggerHandler('change');
                                            }
                                            return false;
                                        }
                                        break;
                                }
                            } else {
                                var reversedDict = {};
                                var dict = typeof col.dict == 'string' ? $.getSysDict(col.dict).items : col.dict;
                                options.source = ['全部'].concat($.map(dict, function (n) {
                                    var $label = $(n.itemName);
                                    var label = $label.length == 0 ? n.itemName : $label.text();
                                    reversedDict[label] = n.itemValue;
                                    reversedDict[n.itemValue] = label;
                                    return {label: label, value: label, html: n.itemName};
                                }));
                                options.create = function (event, ui) {
                                    $(event.target).data(FILTER_COMPUTE, function (value) {
                                        return reversedDict[value];
                                    });
                                    $field.val(reversedDict[col.filterValue] || '');
                                    return false;
                                }
                                options.select = function (event, ui) {
                                    $(event.target).triggerHandler('change');
                                    return false;
                                }
                            }
                            $field.autocomplete(options)
                                .keypress(function () {
                                    return false;
                                }).bind('click',function () { // 点击展开选项
                                    $(this).autocomplete("search", "");
                                });
                            $field.data('autocomplete')._renderItem = function (ul, item) {
                                return $("<li>").data("item.autocomplete", item)
                                    .append("<a>" + (item.html||item.label) + "</a>")
                                    .appendTo(ul);
                            };
                        } else {
                            $field.keypress(function (e) {
                                // 回车时自动查询
                                if (13 == e.keyCode) {
                                    $this.triggerHandler('change');
                                }
                            }).val(col.filterValue);
                        }
                        $field.change(function(){
                            $this.trigger("reloadGrid", [{page: 1}]);
                        });
                        if (col.filterKey == false) {
                            $field.attr('disabled', 'disabled');
                        }
                    }
                    $field.appendTo($td).width(col.width - 4);
                });
            }
        }

        // 表格resize后更新过滤字段的宽度
        o.resizeStop = $.wrap(o.resizeStop, null, resizeFilterCols);
        $(window).resize(function () {
            setTimeout(resizeFilterCols, 100);
        });

        function resizeFilterCols() {
            $.each(t.p.colModel, function () {
                $filterRow.find('td.jq_filter_' + this.name + ' :input').width(this.width - 4);
            });
        }
    });
})(jQuery);
