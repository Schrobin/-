package allservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import allbean.inoutBean;
import alldao.inoutDao;


public class UpdateinoutServlet2 extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		String c_idStr= request.getParameter("c_id");
		String c_name = request.getParameter("c_name");
		String c_num = request.getParameter("c_num");
		String c_hn = request.getParameter("c_hn");
		String c_telnum = request.getParameter("c_telnum");
		String c_date = request.getParameter("c_date");
		
		inoutBean bean = new inoutBean();
		int c_id = Integer.parseInt(c_idStr);
		bean.setC_name(c_name);
		bean.setC_id(c_id);
		bean.setC_num(c_num);
		bean.setC_hn(c_hn);
		bean.setC_telnum(c_telnum);
		bean.setC_date(c_date);
		inoutDao dao = new inoutDao();
		dao.updateCar(bean);
		response.setContentType("text/html; charset=UTF-8"); //转码
	    PrintWriter out = response.getWriter();
	    out.flush();
	    out.println("<script>");
	    out.println("alert('公告信息修改成功!');");
	    out.println("window.location.href='ListinoutServlet';");
	    out.println("</script>");
		//response.sendRedirect("ListinoutServlet");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}
}
