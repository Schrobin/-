package allservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import allbean.AdminBean;
import alldao.AdminDao;

/**
 * 修改后显示数据库列表
 * @author Administrator
 *
 */
public class UpdateAdminServletnew extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		AdminDao dao = new AdminDao();
		AdminBean bean =  new AdminBean();
		//String ad_idStr = request.getParameter("ad_id");
		String ad_name = request.getParameter("ad_name");
		String ad_pwd = request.getParameter("ad_pwd");
		String ad_role = request.getParameter("ad_role");
		String ad_cl = request.getParameter("ad_cl");
		//System.out.println(ad_cl);
		String ad_sex = request.getParameter("ad_sex");
		//System.out.println(ad_sex);
		String ad_tf = request.getParameter("ad_tf");
		//System.out.println(ad_tf);
		//int ad_id = Integer.parseInt(ad_idStr);
		//System.out.println(ad_id);
		//bean.setAd_id(ad_id);
		if("".equals(ad_pwd)||ad_pwd.equals(null)){
			 response.setContentType("text/html; charset=UTF-8"); //转码
			    PrintWriter out = response.getWriter();
			    out.flush();
			    out.println("<script>");
			    out.println("alert('登陆密码不能为空！请重新输入');");
			    out.println("history.back();");
			    out.println("</script>");	
		}else if("".equals(ad_sex)||ad_sex.equals(null)){
			 response.setContentType("text/html; charset=UTF-8"); //转码
			    PrintWriter out = response.getWriter();
			    out.flush();
			    out.println("<script>");
			    out.println("alert('交易密码不能为空！请重新输入');");
			    out.println("history.back();");
			    out.println("</script>");	
		}else{
		bean.setAd_name(ad_name);
		bean.setAd_pwd(ad_pwd);
		bean.setAd_role(ad_role);
		bean.setAd_cl(ad_cl);
		bean.setAd_sex(ad_sex);
		bean.setAd_tf(ad_tf);
		dao.updateAdminnew(bean);
	      PrintWriter out = response.getWriter();
	      String a = "个人信息维护成功!";
	      out.write(a);
	      out.flush();
	      out.close();
		}
		//response.sendRedirect("main。html");
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}
}
