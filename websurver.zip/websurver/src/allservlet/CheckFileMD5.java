package allservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import allbean.FileMD5;

public class CheckFileMD5 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=UTF-8");
		FileMD5 fm = new FileMD5();
		String originalMD5 = request.getParameter("originalmd5");
		System.out.println("页面接收：" + originalMD5);
		fm.setOriginalMD5(originalMD5);
		HttpSession session = request.getSession();
		String fileMD5 = String.valueOf(session.getAttribute("fileMD5"));
		System.out.println("originalMD5:" + fm.getOriginalMD5());
		System.out.println("fileMD5:" + fileMD5);
		if (session.getAttribute("message") == null) {

		} else {
			session.setAttribute("message", " ");
		}
		if (fileMD5.equals(fm.getOriginalMD5())) {
			PrintWriter out = response.getWriter();
			session.setAttribute("message", "文件没有被篡改过，安全。");
			out.println("<script>");
			out.println("window.location.href='/websurver/checkFile.jsp';");
			out.println("</script>");
			return;
		} else {
			PrintWriter out = response.getWriter();
			session.setAttribute("message", "该文件被篡改过，请注意！");
			out.println("<script>");
			out.println("window.location.href='/websurver/checkFile.jsp';");
			out.println("</script>");
			return;
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}
}
