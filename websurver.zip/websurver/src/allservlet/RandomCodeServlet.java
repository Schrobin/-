package allservlet;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class RandomCodeServlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3952051403367337978L;
	//验证图片的宽�?,高度
	private int width = 60;
	private int height = 20;
	
	protected void service(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException {
		BufferedImage buffImg = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
		Graphics2D g =  buffImg.createGraphics();
		
		
		g.setColor(Color.white);
		g.fillRect(0, 0, width, height);
		
		//创建字体，字体的大小应该根据图片的高度决�?
		Font font = new Font("宋体",Font.PLAIN,18);
		//设置字体
		g.setFont(font);
		
		//画边�?
		g.setColor(Color.red);
		g.drawRect(0, 0, width-1, height-1);
		
		//随机产生10条干扰线，使图像中的认证码不易被其他程序探测�?
		g.setColor(Color.yellow);
//		创建�?个随机数生成器类
		Random random = new Random();
		//1-25
		
		for(int i=0;i<10;i++){
			int x = random.nextInt(width);
			int y = random.nextInt(height);
			g.drawLine(x, y, x+3, y+5);
		}
		
		//randomCode用于保存随机产生的验证码，以便于用户登录后进行验�?
		StringBuffer randomCode = new StringBuffer();
		int red=0;
		int green = 0;
		int blue = 0;
		//随机产生4位数的随机码
		for(int i=0;i<4;i++){
			//得到随机厂商的验证码数字
			int a = random.nextInt(26);
			String b = (char)('a'+a)+"";
			//产生随机产生的颜色分量来构�?�颜色�?�，这样输出的每位数字的颜色值都将不�?
			red = random.nextInt(255);
			green = random.nextInt(255);
			blue = random.nextInt(255);
			
			//用随机产生的颜色将验证码绘制到图像中
			
			g.setColor(new Color(red,green,blue));
			g.drawString(b, 13*i+6, 16);
			
			//将产生的4个随机数组合在一�?
			randomCode.append(b);
		}
		//wjdh
		
		//�?4位数字的验证码保存到Session�?
		HttpSession session = req.getSession();
		session.setAttribute("randomCode", randomCode.toString());
		
		//禁止图像缓存
		res.setHeader("Pragma", "no-cache");
		res.setHeader("Cache-Controller", "no-cache");
		res.setDateHeader("Expires", 0);
		
		
		res.setContentType("image/jpeg");
		//将图像输出到Servlet输出流中
		ServletOutputStream sos = res.getOutputStream();
		ImageIO.write(buffImg,"jpeg",sos);
		sos.close();
		
		
	}
	
	
}
