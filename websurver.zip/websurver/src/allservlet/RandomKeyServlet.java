package allservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.RandomKey;

public class RandomKeyServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=UTF-8");
		HttpSession session = request.getSession();
		session.removeAttribute("randomkey");
		RandomKey random = new RandomKey();
		String key = request.getParameter("randomkey");
		int num = 0;
		PrintWriter out = response.getWriter();
		out.flush();
		out.print(key);
		String randomKey = random.getChar(32);
		session.setAttribute("randomkey", randomKey);
		session.setAttribute("num", num);
		System.out.println(randomKey);
		// response.setHeader("location", "randomKey.jsp");
		out.println("<script>");
		out.println("window.location.href='/websurver/randomKey.jsp';");
		out.println("</script>");
		return;
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		this.doGet(request, response);
	}
}
