package allservlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import util.CheckFolderSum;

public class CheckFileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=UTF-8");
		try {
			HttpSession session = request.getSession();
			if (session.getAttribute("fileMD5") == null || session.getAttribute("filename") == null) {
				session.setAttribute("fileMD5", " ");
				session.setAttribute("filename", " ");
			} else {
				session.removeAttribute("fileMD5");
				session.removeAttribute("filename");
			}
			DiskFileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);
			String name = "";
			String filename = "";
			String value = "";
			List<FileItem> list = upload.parseRequest(request);
			for (FileItem item : list) {
				/*
				 * 可以使用该方法判断是否为普通表单域true，还是文件上传表单域false。
				 */
				if (item.isFormField()) {
					name = item.getFieldName();
					value = item.getString("UTF-8");
				} else {
					filename = "e:\\" + item.getName();
				}
			}
			File file = new File(filename);
			CheckFolderSum checkSum = new CheckFolderSum();
			// String string = checkSum.traverseFolder(file, ".no");
			String string = checkSum.checkMd5(file);
			session.setAttribute("fileMD5", string);
			session.setAttribute("filename", filename);
			System.out.println(string);
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("window.location.href='/websurver/checkFile.jsp';");
			out.println("</script>");
			return;
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			response.setContentType("text/html; charset=UTF-8"); // 转码
			response.setContentType("text/html; charset=UTF-8"); // 转码
			PrintWriter out = response.getWriter();
			out.flush();
			out.println("<script>");
			out.println("alert('请选择文件！');");
			out.println("history.back();");
			out.println("</script>");
		}

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}
}
