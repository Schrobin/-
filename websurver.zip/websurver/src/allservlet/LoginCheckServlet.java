package allservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginCheckServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2666182843797118762L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession session = req.getSession();
		//得到session中的验证�?
		String randomCode = (String)session.getAttribute("randomCode");
		
		//得到用户输入的验证码
		String reqRandom = req.getParameter("random");
		
		res.setContentType("text/html;charset=utf-8");
		PrintWriter out = res.getWriter();
		
		if(randomCode.equals(reqRandom)) {
			out.print("验证码匹配");
		} else {
			out.print("验证码校验失败，请重新输入");
		}
		out.close();
		
		
	}

	@Override
	protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		this.doGet(arg0, arg1);
	}
	
}
