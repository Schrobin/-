package allservlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import allbean.inoutBean;
import alldao.inoutDao;


public class AddinoutServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		Date now =new Date();
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd hh:mm");
		//String nowStr=format.format(now);
		String c_name = request.getParameter("c_name");
		String c_num = format.format(now);
		String c_hn = request.getParameter("c_hn");
		String c_telnum = request.getParameter("c_telnum");
		String c_date = request.getParameter("c_date");
		
		inoutBean bean = new inoutBean();
		bean.setC_name(c_name);
		bean.setC_num(c_num);
		bean.setC_hn(c_hn);
		bean.setC_telnum(c_telnum);
		bean.setC_date(c_date);
		
		inoutDao dao = new inoutDao();
		dao.addCar(c_name,c_num,c_hn,c_telnum,c_date);
		response.setContentType("text/html; charset=UTF-8"); //转码
	    PrintWriter out = response.getWriter();
	    out.flush();
	    out.println("<script>");
	    out.println("alert('公告信息添加成功!');");
	    out.println("window.location.href='ListinoutServlet';");
	    out.println("</script>");
		//response.sendRedirect("ListinoutServlet");
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	this.doGet(request, response);
	}

}
