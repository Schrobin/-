package allservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpSession;

import allbean.AdminBean;
import alldao.AdminDao;

/**
 * 在修改界面显示原来的数据
 * @author Administrator
 *
 */

public class UpdateAdminServlet2new extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		AdminBean bean = (AdminBean)session.getAttribute("bean");
		    String name = bean.getAd_name();
		//String ad_id = request.getParameter("ad_id");
		AdminDao dao = new AdminDao();
		AdminBean beannew = dao.getAdminByBeannew(name);	
		 //System.out.println(beannew);
		request.setAttribute("bean1", beannew);
		RequestDispatcher dispacher = request.getRequestDispatcher("updateAdminnew.jsp");
		dispacher.forward(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
