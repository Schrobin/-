package allservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import allbean.AdminBean;
import alldao.AdminDao;


public class AddAdminServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String ad_name = request.getParameter("ad_name");
		String ad_pwd = request.getParameter("ad_pwd");
		String ad_role = request.getParameter("ad_role");
		String ad_cl = request.getParameter("ad_cl");
		String ad_sex = request.getParameter("ad_sex");
		String ad_tf = "0";
		if("".equals(ad_pwd)||ad_pwd.equals(null)){
			 response.setContentType("text/html; charset=UTF-8"); //转码
			    PrintWriter out = response.getWriter();
			    out.flush();
			    out.println("<script>");
			    out.println("alert('登陆密码不能为空！请重新输入');");
			    out.println("history.back();");
			    out.println("</script>");	
		}else{
		AdminBean bean = new AdminBean();
		bean.setAd_name(ad_name);
		bean.setAd_pwd(ad_pwd);
		bean.setAd_role(ad_role);
		bean.setAd_cl(ad_cl);
		bean.setAd_sex(ad_sex);
		bean.setAd_tf(ad_tf);
		AdminDao dao = new AdminDao();
		dao.addAdmin1(bean);
		response.setContentType("text/html; charset=UTF-8"); //转码
	    PrintWriter out = response.getWriter();
	    out.flush();
	    out.println("<script>");
	    out.println("alert('信息添加成功!');");
	    out.println("window.location.href='listAdmin.jsp';");
	    out.println("</script>");
		}
		
		/*response.setContentType("text/html; charset=UTF-8"); //转码
	    PrintWriter out = response.getWriter();
	    out.flush();
	    out.println("<script>");
	    out.println("alert('用户添加成功!');");
	    out.println("history.back();");
	    out.println("</script>");
		response.sendRedirect("listAdmin.jsp");*/
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
