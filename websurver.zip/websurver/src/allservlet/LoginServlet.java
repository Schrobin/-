package allservlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import allbean.AdminBean;
import alldao.AdminDao;


public class LoginServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		String username = request.getParameter("username");
		String pwd = request.getParameter("pwd");
		String ad_role = request.getParameter("ad_role");
		String isRecord = request.getParameter("isRecord");//选中，有值。如果没有选中，NULL
		String randomCode = request.getParameter("randomCode");
		HttpSession session = request.getSession();
		if(session.getAttribute("randomCode").toString().equalsIgnoreCase(randomCode)){
		//选中状态
		if(isRecord!=null){
			//cookie是程序员自己创建
			Cookie nameCookie = new Cookie("username",username);
			//cookie的存活时间
			nameCookie.setMaxAge(3600*24);
			//如何把cookie发送给客户端
			response.addCookie(nameCookie);
			Cookie pwdCookie=new Cookie("pwd",pwd);
			pwdCookie.setMaxAge(36000*24);
			response.addCookie(pwdCookie);
		}

		
		//记录登录时间
		Date now =new Date();
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-ddhh:mm");
		String nowStr=format.format(now);
		Cookie dateCookie=new Cookie("loginTime",nowStr);
		dateCookie.setMaxAge(30*24*3600);
		response.addCookie(dateCookie);
		AdminBean bean =new AdminDao().getAdmin(username,pwd,ad_role);
		
		if (bean!=null){
			//HttpSession session=request.getSession();
			session.setAttribute("bean", bean);
			response.sendRedirect("main.html");
		}else{
			request.setAttribute("errorMsg","用户名密码错误或角色选择错误!" );
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		}else{
			request.setAttribute("errorMsg","验证码错误!" );
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
