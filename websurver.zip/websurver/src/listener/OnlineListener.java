package listener;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class OnlineListener implements HttpSessionListener{

	public void sessionCreated(HttpSessionEvent event) {
		//在线人数+1 application
		ServletContext application = event.getSession().getServletContext();
		Integer count = (Integer)application.getAttribute("onCount");
		if(count==null){
			application.setAttribute("onCount", 1);
		}else{
			application.setAttribute("oncount", count+1);
			
		}
	}

	public void sessionDestroyed(HttpSessionEvent event) {
//		在线人数-1 application
		ServletContext application = event.getSession().getServletContext();
		Integer count = (Integer)application.getAttribute("onCount");
		if(count==null){
			application.setAttribute("onCount", 1);
		}else{
			application.setAttribute("oncount", count-1);
			
		}
	}
		
}
