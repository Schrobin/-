package test;

import java.io.File;

import util.CheckFolderSum;

public class TestCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String filepath = "d:/AES/AES.txt";
		File file = new File(filepath);
		CheckFolderSum checkSum = new CheckFolderSum();
		// String string = checkSum.traverseFolder(file, ".no");
		String string = checkSum.checkMd5(file);
		System.out.println("文件MD5值：" + string);
	}
}
