package test;

import util.RandomKey;

public class TestRandom {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RandomKey random = new RandomKey();
		System.out.print(random.getChar(32));
	}

}
