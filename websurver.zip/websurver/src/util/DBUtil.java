package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/**
 * 锟斤拷菘獬ｏ拷梅锟斤拷锟�
 * @author wanglixia
 * @version 1.0
 *
 */
public class DBUtil {
	/**
	 *锟斤拷锟斤拷锟斤拷锟斤拷
	 * @return 锟斤拷锟斤拷
	 */
	public static Connection getConnection() {
		try {
			//Class.forName("oracle.jdbc.OracleDriver");
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection conn = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/orcl?characterEncoding=utf8&useSSL=true","root","rootroot");
			 //conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
		
	}
	/**
	 * 锟截憋拷锟斤拷锟斤拷
	 * @param conn 锟斤拷锟斤拷
	 */
	public static void closeConn(Connection conn){
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	/**
	 * 锟截憋拷锟斤拷锟斤拷锟斤拷源
	 * @param conn 锟斤拷锟斤拷
	 * @param stmt Statement锟斤拷锟斤拷
	 * @param rs 锟斤拷锟�
	 */
	public static void closeAll(Connection conn,Statement stmt,ResultSet rs){
		if(rs!=null){
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(stmt!=null){
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		/*Connection conn = getConnection();
		System.out.println(conn);
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}*/
		String str = "<abcd efg>higklmnopq<rstu vwxyz";
        System.out.println(str.substring(str.indexOf(">")+1, str.lastIndexOf("<")));
	}
}
