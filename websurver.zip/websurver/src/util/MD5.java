package util;

import java.io.File;

import org.apache.commons.codec.digest.DigestUtils;

public class MD5 {
	public static String md5(String text, String key) throws Exception {
		String md5str = DigestUtils.md5Hex(text + key);
		return md5str;
	}
	public static String md52(String text) throws Exception {
		String md5str = DigestUtils.md5Hex(text);
		return md5str;
	}
	public static boolean verify(String text, String key, String md5) throws Exception {
		String md5str = md5(text, key);
		if (md5str.equalsIgnoreCase(md5)) {
			return true;
		}else{
		}
		return false;
	}
public static void main(String[] args) {
		
		String a = "RUN";
		String b = "123456";
		String c = "f3f64c7c9cb4792bc97d2142c201c222";
		boolean value;
		try {
			value = Md5Util.verify(a,b,c);
			System.out.println(value);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
         
	}


}
