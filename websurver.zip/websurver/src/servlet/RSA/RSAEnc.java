package servlet.RSA;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringUtils;

import util.FileEncAndDec;
import util.Md5Util;
import util.RSAUtil;

public class RSAEnc extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		try{
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload upload = new ServletFileUpload(factory);
		List<FileItem> list = upload.parseRequest(request);
		String name = "";
		String filename = "";
		String value = "";
		FileWriter writer;
        for(FileItem item : list){
            if(item.isFormField()){
                 name = item.getFieldName();        
                 value = item.getString("UTF-8");   
          
            }else{
                 filename = "E:\\"+item.getName();
            }        
	}
		File srcFile = new File(filename);
		File encFile = new File(StringUtils.substringBeforeLast(filename, ".")+"RSAenc.txt");
		RSAUtil enc = new RSAUtil();
		if(!srcFile.exists()){
			response.setContentType("text/html; charset=UTF-8"); //转码
		    PrintWriter out = response.getWriter();
		    out.flush();
		    out.println("<script>");
		    out.println("alert('待加密文件不存在!');");
		    out.println("history.back();");
		    out.println("</script>");
            return;
       }else{
    	String message = RSAUtil.txt2String(srcFile).trim();
    	Map<Integer, String> keyMap = new HashMap<Integer, String>();
    		KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");  
    		keyPairGen.initialize(1024,new SecureRandom());  
    		KeyPair keyPair = keyPairGen.generateKeyPair();  
    		RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();   
    		RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic(); 
    		String publicKeyString = new String(Base64.encodeBase64(publicKey.getEncoded())); 
    		String privateKeyString = new String(Base64.encodeBase64((privateKey.getEncoded())));  
    		keyMap.put(0,publicKeyString); 
    		keyMap.put(1,privateKeyString); 
    	String messageEn = RSAUtil.encrypt(message,keyMap.get(0));
    	 writer = new FileWriter(encFile);
         writer.write(messageEn);
         writer.flush();
         writer.close();
         request.setAttribute("Infomation1","加密的公钥"+keyMap.get(0) );
 	    request.setAttribute("Infomation2","解密的私钥"+keyMap.get(1) );
 		request.getRequestDispatcher("RSAEnc.jsp").forward(request, response); 
       }
		}catch (Exception e) {
			e.printStackTrace();
			 response.setContentType("text/html; charset=UTF-8"); //转码
			    PrintWriter out = response.getWriter();
			    out.flush();
			    out.println("<script>");
			    out.println("alert('文件加密失败');");
			    out.println("history.back();");
			    out.println("</script>");
        }
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
