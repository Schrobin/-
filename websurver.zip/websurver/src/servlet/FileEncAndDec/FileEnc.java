package servlet.FileEncAndDec;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringUtils;

import util.FileEncAndDec;
import util.Md5Util;

public class FileEnc extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		try{
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload upload = new ServletFileUpload(factory);
		List<FileItem> list = upload.parseRequest(request);
		String name = "";
		String filename = "";
		String value = "";
		int miyao = 0 ;
		FileWriter writer;
        for(FileItem item : list){
            if(item.isFormField()){
                 name = item.getFieldName();        
                 value = item.getString("UTF-8");   
                 miyao =  Integer.parseInt(value);
            }else{
                 filename = "E:\\"+item.getName();
            }        
	}
		File srcFile = new File(filename);
		File encFile = new File(StringUtils.substringBeforeLast(filename, ".")+"enc"+miyao+".txt");
		System.out.println("lalalalalal:"+encFile);
		FileEncAndDec enc = new FileEncAndDec();
		if(!srcFile.exists()){
			response.setContentType("text/html; charset=UTF-8"); //转码
		    PrintWriter out = response.getWriter();
		    out.flush();
		    out.println("<script>");
		    out.println("alert('待加密文件不存在!');");
		    out.println("history.back();");
		    out.println("</script>");
            return;
       }else if(value.equals(null)||"".equals(value)){
    	   response.setContentType("text/html; charset=UTF-8"); //转码
   	    PrintWriter out = response.getWriter();
   	    out.flush();
   	    out.println("<script>");
   	    out.println("alert('密钥不能为空，请填写密钥!');");
   	    out.println("history.back();");
   	    out.println("</script>");
    	   
       }else{
		enc.EncFile(srcFile, encFile,miyao);
        response.setContentType("text/html; charset=UTF-8"); //转码
	    PrintWriter out = response.getWriter();
	    out.flush();
	    out.println("<script>");
	    out.println("alert('文件加密成功');");
	    out.println("history.back();");
	    out.println("</script>");
       }
		}catch (Exception e) {
			e.printStackTrace();
			 response.setContentType("text/html; charset=UTF-8"); //转码
			    PrintWriter out = response.getWriter();
			    out.flush();
			    out.println("<script>");
			    out.println("alert('文件加密失败');");
			    out.println("history.back();");
			    out.println("</script>");
        }
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
