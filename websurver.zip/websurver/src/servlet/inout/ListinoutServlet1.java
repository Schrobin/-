package servlet.inout;

import java.io.IOException;
import java.util.List;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import allbean.PageBean;
import allbean.inoutBean;
import alldao.inoutDao;

public class ListinoutServlet1 extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String c_name = request.getParameter("c_name");
		/*if (c_name==null){}else{
			byte[] c_name1 = c_name.getBytes("utf-8");//编码  
			System.out.printf("c_name1="+c_name1);
			String c_name2 = new String(c_name1, "utf-8");
			System.out.printf("c_name2="+c_name2);
		}*/
		String c_num = request.getParameter("c_num");
		String c_hn = request.getParameter("c_hn");
		String c_telnum = request.getParameter("c_telnum");
		String c_date = request.getParameter("c_date");
		String pageStr = request.getParameter("page");
		if (pageStr == null) {
			pageStr = "1";
		}
		int page = Integer.parseInt(pageStr);

		inoutDao dao = new inoutDao();
		int totalCount = dao.getTotalCount(c_name, c_num);
		int totalPage = PageBean.getTotalPage(totalCount);
		List<inoutBean> list = dao.getAllCars(c_name, c_num, c_hn, c_telnum,c_date);
		request.setAttribute("list", list);
		request.setAttribute("c_name", c_name);
		request.setAttribute("c_num", c_num);
		request.setAttribute("c_hn", c_hn);
		request.setAttribute("c_telnum", c_telnum);
		request.setAttribute("c_date", c_date);
		request.setAttribute("currentPage", page);
		request.setAttribute("totalCount", totalCount);
		request.setAttribute("totalPage", totalPage);
		request.getRequestDispatcher("listinout1.jsp").forward(request,
				response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
