package servlet.MD5;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import util.Md5Util;

public class DecryptMD5 extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String file_mingwen = request.getParameter("file_mingwen");
		System.out.println(file_mingwen);
		String file_password = request.getParameter("file_password");
		System.out.println(file_password);
		String file_miwen = request.getParameter("file_miwen");
		System.out.println(file_miwen);
		Md5Util md5util = new Md5Util();
		try {
			boolean run=md5util.verify(file_mingwen,file_password,file_miwen);
			String run1 = run+"";
			if ("true".equals(run1)){
				 response.setContentType("text/html; charset=UTF-8"); //转码
				    PrintWriter out = response.getWriter();
				    out.flush();
				    out.println("<script>");
				    out.println("alert('MD5密钥验证通过!');");
				    out.println("history.back();");
				    out.println("</script>");
			}else{
				 response.setContentType("text/html; charset=UTF-8"); //转码
				    PrintWriter out = response.getWriter();
				    out.flush();
				    out.println("<script>");
				    out.println("alert('MD5密钥验证失败!');");
				    out.println("history.back();");
				    out.println("</script>");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
