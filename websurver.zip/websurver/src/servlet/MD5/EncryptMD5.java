package servlet.MD5;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import util.Md5Util;

public class EncryptMD5 extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		try {
			DiskFileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);
			List<FileItem> list = upload.parseRequest(request);
			String name = "";
			String filename = "";
			String value = "";
			FileWriter writer;
			for (FileItem item : list) {
				if (item.isFormField()) {
					name = item.getFieldName();
					value = item.getString("UTF-8");
				} else {
					filename = "E:\\" + item.getName();
				}
			}
			String valuemd5 = "";
			File file = new File(filename);
			Md5Util md5util = new Md5Util();
			String str = md5util.txt2String(file).trim();
			String key = value;
			valuemd5 = DigestUtils.md5Hex(str + key);
			String fileOut = file.getPath() + ".md5";
			writer = new FileWriter(fileOut);
			writer.write(valuemd5);
			writer.flush();
			writer.close();
			response.setContentType("text/html; charset=UTF-8"); // 转码
			PrintWriter out = response.getWriter();
			out.flush();
			out.println("<script>");
			out.println("alert('文件加密成功');");
			out.println("history.back();");
			out.println("</script>");
		} catch (Exception e) {
			response.setContentType("text/html; charset=UTF-8"); // 转码
			PrintWriter out = response.getWriter();
			out.flush();
			out.println("<script>");
			out.println("alert('文件加密失败');");
			out.println("history.back();");
			out.println("</script>");
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		this.doGet(request, response);
	}

}
