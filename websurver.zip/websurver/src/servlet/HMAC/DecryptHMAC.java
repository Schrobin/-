package servlet.HMAC;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringUtils;

import util.HMAC;
import util.Md5Util;

public class DecryptHMAC extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		try {
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload upload = new ServletFileUpload(factory);
		List<FileItem> list = upload.parseRequest(request);
		String name = "";
		String filename = "";
		String value = "";
        for(FileItem item : list){
            if(item.isFormField()){
                 name = item.getFieldName();        
                 value = item.getString("UTF-8");
            }else{
                 filename = "E:\\"+item.getName();
            }        
	    }
        int index=filename.indexOf(".");
        index=filename.indexOf(".", index+1);
        String key=filename.substring(index);
        String key1=key.substring(0, key.indexOf("."));
        String key2=key.substring(key1.length()+1, key.length());
        if(value.equals(key2)){
        	 response.setContentType("text/html; charset=UTF-8"); //转码
			    PrintWriter out = response.getWriter();
			    out.flush();
			    out.println("<script>");
			    out.println("alert('密码验证成功!');");
			    out.println("history.back();");
			    out.println("</script>");
        
        }else{
        	response.setContentType("text/html; charset=UTF-8"); //转码
		    PrintWriter out = response.getWriter();
		    out.flush();
		    out.println("<script>");
		    out.println("alert('密码错误!');");
		    out.println("history.back();");
		    out.println("</script>");
        }
        }catch(Exception e){
        	e.printStackTrace();
        	response.setContentType("text/html; charset=UTF-8"); //转码
		    PrintWriter out = response.getWriter();
		    out.flush();
		    out.println("<script>");
		    out.println("alert('密码验证失败!');");
		    out.println("history.back();");
		    out.println("</script>");
        }
			
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
