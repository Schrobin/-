package servlet.admin;

import java.io.IOException;
import java.util.List;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import allbean.AdminBean;
import allbean.PageBean;
import alldao.AdminDao;

public class ListAdminServlet1 extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String ad_name = request.getParameter("ad_name");
		String ad_pwd = request.getParameter("ad_pwd");
		String ad_role = request.getParameter("ad_role");
		String ad_cl = request.getParameter("ad_cl");
		String ad_sex = request.getParameter("ad_sex");
		String ad_tf = request.getParameter("ad_tf");
		String pageStr = request.getParameter("page");
		if (pageStr == null) {
			pageStr = "1";
		}
		int page = Integer.parseInt(pageStr);
		AdminDao dao = new AdminDao();
			int totalCount = dao.getTotalCount(ad_name, ad_role);
			int totalPage = PageBean.getTotalPage(totalCount);
			List<AdminBean> list = dao.getAllCarsG(ad_name,ad_role);
			System.out.print("YYYYYY:"+list);
			request.setAttribute("list", list);
			request.setAttribute("ad_name", ad_name);
			request.setAttribute("ad_pwd", ad_pwd);
			request.setAttribute("ad_role", ad_role);
			request.setAttribute("ad_cl", ad_cl);
			request.setAttribute("ad_sex", ad_sex);
			request.setAttribute("ad_tf", ad_tf);
			request.setAttribute("currentPage", page);
			request.setAttribute("totalCount", totalCount);
			request.setAttribute("totalPage", totalPage);
			request.getRequestDispatcher("listAdmin2.jsp").forward(request,response);
		}
		
		

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
