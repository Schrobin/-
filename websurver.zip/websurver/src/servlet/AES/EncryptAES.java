package servlet.AES;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.AES;

public class EncryptAES extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		try {
			String content = "对面的楼上的男生，你们有女朋友吗？";
			String password = "123456789";
			System.out.println("加密之前：" + content);

			// 加密
			byte[] encrypt = AES.encrypt(content, password);
			System.out.println("加密后的内容：" + new String(encrypt));

		} catch (Exception e) {
			response.setContentType("text/html; charset=UTF-8"); // 转码

		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		this.doGet(request, response);
	}
}
