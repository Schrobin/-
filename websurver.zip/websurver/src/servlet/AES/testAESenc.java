package servlet.AES;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import util.AES;

public class testAESenc {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		// 加密
		File srcFile = new File("d:/AES.txt");
		File enFile = new File("d:/AESenc.txt");
		String message = AES.txt2String(srcFile).trim();
		byte[] encrypt = AES.encrypt(message, "123456");
		// 选择流
		OutputStream os = null;
		try {
			// 以追加的形式写true
			os = new FileOutputStream(enFile);

			// 字符串转字节数组
			byte[] date = encrypt;
			try {
				os.write(date, 0, date.length);
				os.flush();// 强制刷新出去
			} catch (IOException e) {
				e.printStackTrace();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("文件未找到");
		} finally {
			if (null != os) {
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

}
