package servlet.AES;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import util.AES;

public class testAESdec {

	public static void main(String[] args) throws IOException {
		// 解密 第1步、使用File类找到一个文件
		File enFile = new File("d:/AESenc.txt");
		File deFile = new File("d:/AESdec.txt");
		// 第2步、通过子类实例化父类对象
		FileInputStream input = new FileInputStream(enFile); // 通过对象多态性，进行实例化
		OutputStream output = new FileOutputStream(deFile);
		// 第3步、进行读操作
		byte b[] = new byte[1024]; // 所有的内容都读到此数组之中
		int len;
		// input.read(b); // 读取内容 网络编程中 read 方法会阻塞
		// 第4步、关闭输出流

		while ((len = input.read(b)) != -1) {
			byte[] effective = new byte[len];
			System.arraycopy(b, 0, effective, 0, len);
			System.out.println(new String(effective, "utf-8"));
			for (byte c : effective) {
				System.out.print(c + " ");
			}
			byte[] d = AES.decrypt(effective, "123456");
			System.out.println();
			System.out.println("解密后的内容：" + new String(d));
			String str = new String(d);

			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, "UTF-8"));
			writer.write(str);
			writer.close();
		}
		input.close(); // 关闭输出流
	}

}
