package servlet.AES;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringUtils;

import util.AES;

public class AESEnc extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		try {
			// 创建一个新的文件上传句柄
			DiskFileItemFactory factory = new DiskFileItemFactory();
			/*
			 * ServletFileUpload负责处理上传的文件数据,并将表单中每个输入项封装成一个FileItem对象中
			 */
			ServletFileUpload upload = new ServletFileUpload(factory);
			/*
			 * parseRequest(HttpServletRequest)方法 可以将通过表单中每一个HTML标签提交的数据封装成一个FileItem对象，
			 * 然后以List列表的形式返回
			 */
			List<FileItem> list = upload.parseRequest(request);
			String name = "";
			String filename = "";
			String value = "";
			FileWriter writer;
			for (FileItem item : list) {
				/*
				 * 可以使用该方法判断是否为普通表单域true，还是文件上传表单域false。
				 */
				if (item.isFormField()) {
					name = item.getFieldName();
					value = item.getString("UTF-8");
				} else {
					filename = "e:\\" + item.getName();
				}
			}
			// 目标文件
			File srcFile = new File(filename);
			// 截取不包含后缀的上传文件名，然后重新生成加密后的文件名
			File encFile = new File(StringUtils.substringBeforeLast(filename, ".") + "AESenc.txt");

			if (!srcFile.exists()) {
				response.setContentType("text/html; charset=UTF-8"); // 转码
				PrintWriter out = response.getWriter();
				out.flush();
				out.println("<script>");
				out.println("alert('待加密文件不存在!');");
				out.println("history.back();");
				out.println("</script>");
				return;
			} else {
				String message = AES.txt2String(srcFile).trim();
				byte[] encrypt = AES.encrypt(message, value);
				OutputStream os = null;
				try {
					os = new FileOutputStream(encFile);
					byte[] date = encrypt;
					try {
						os.write(date, 0, date.length);
						os.flush();
					} catch (IOException e) {
						e.printStackTrace();
					}

				} catch (FileNotFoundException e) {
					e.printStackTrace();
					System.out.println("文件未找到");
				} finally {
					if (null != os) {
						try {
							os.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
				response.setContentType("text/html; charset=UTF-8");
				PrintWriter out = response.getWriter();
				out.flush();
				out.println("<script>");
				out.println("alert('文件加密成功');");
				out.println("history.back();");
				out.println("</script>");
			}

		} catch (Exception e) {
			response.setContentType("text/html; charset=UTF-8"); // 转码
			response.setContentType("text/html; charset=UTF-8"); // 转码
			PrintWriter out = response.getWriter();
			out.flush();
			out.println("<script>");
			out.println("alert('文件加密失败');");
			out.println("history.back();");
			out.println("</script>");
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		this.doGet(request, response);
	}
}
