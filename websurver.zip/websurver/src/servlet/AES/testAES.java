package servlet.AES;

import util.AES;

public class testAES {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String content = "对面的楼上的男生，你们有女朋友吗？";
		String password = "123456789";
		System.out.println("加密之前：" + content);

		// 加密
		byte[] encrypt = AES.encrypt(content, password);
		System.out.println("加密后的内容：" + new String(encrypt));

		// 解密
		byte[] decrypt = AES.decrypt(encrypt, password);
		System.out.println("解密后的内容：" + new String(decrypt));
	}

}
