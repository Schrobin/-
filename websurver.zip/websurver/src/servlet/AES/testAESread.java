package servlet.AES;

import java.io.File;

import util.AES;

public class testAESread {

	public static void main(String[] args) {
		File srcFile = new File("d:/AESenc.txt");
		String message = AES.txt2String(srcFile).trim();
		System.out.println(message);
	}

}
