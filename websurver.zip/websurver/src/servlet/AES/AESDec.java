package servlet.AES;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringUtils;

import util.AES;

public class AESDec extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		try {
			DiskFileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);
			List<FileItem> list = upload.parseRequest(request);
			String name = "";
			String filename = "";
			String value = "";
			FileWriter writer;
			for (FileItem item : list) {
				if (item.isFormField()) {
					name = item.getFieldName();
					value = item.getString("UTF-8");
				} else {
					filename = "E:\\" + item.getName();
				}
			}

			File encFile = new File(filename);
			File decFile = new File(StringUtils.substringBeforeLast(filename, "enc") + "dec.txt");

			if (!encFile.exists()) {
				response.setContentType("text/html; charset=UTF-8"); // 转码
				PrintWriter out = response.getWriter();
				out.flush();
				out.println("<script>");
				out.println("alert('待解密文件不存在!');");
				out.println("history.back();");
				out.println("</script>");
				return;
			} else {
				FileInputStream input = new FileInputStream(encFile);
				OutputStream output = new FileOutputStream(decFile);
				byte b[] = new byte[209715200]; // 所有的内容都读到此数组之中
				int len;
				while ((len = input.read(b)) != -1) {
					byte[] effective = new byte[len];
					System.arraycopy(b, 0, effective, 0, len);
					// System.out.println(new String(effective, "utf-8"));
					// for (byte c : effective) {
					// System.out.print(c + " ");
					// }
					byte[] d = AES.decrypt(effective, value);
					// System.out.println();
					// System.out.println("解密后的内容：" + new String(d));
					String str = new String(d);

					BufferedWriter bwriter = new BufferedWriter(new OutputStreamWriter(output, "UTF-8"));
					bwriter.write(str);
					bwriter.close();
				}
				input.close(); // 关闭输出流

				response.setContentType("text/html; charset=UTF-8"); // 转码
				PrintWriter out = response.getWriter();
				out.flush();
				out.println("<script>");
				out.println("alert('文件解密成功!');");
				out.println("history.back();");
				out.println("</script>");
			}

		} catch (Exception e) {
			e.printStackTrace();
			response.setContentType("text/html; charset=UTF-8"); // 转码
			PrintWriter out = response.getWriter();
			out.flush();
			out.println("<script>");
			out.println("alert('私钥错误!文件解密失败!');");
			out.println("history.back();");
			out.println("</script>");
		}
		// byte[] decrypt = AES.decrypt(encrypt, password);
		// System.out.println("解密后的内容：" + new String(decrypt));
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		this.doGet(request, response);
	}
}
