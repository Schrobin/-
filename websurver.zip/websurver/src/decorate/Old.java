package decorate;

import java.io.UnsupportedEncodingException;

public class Old implements IDecorate {
	/* (non-Javadoc)
	 * @see com.weixin.decorate.IDecorate#getParameter(java.lang.String)
	 */
	public String getParameter(String param){
		
		String result = null;
		try {
			byte[] array = param.getBytes("utf-8");
			result = new String(array,"iso-8859-1");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		return result;
	}
}
