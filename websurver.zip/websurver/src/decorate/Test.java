package decorate;

public class Test {
	public static void main(String[] args) {
		IDecorate old = new Old();
		IDecorate decorate = new Decorate(old);
		String result = decorate.getParameter("中文");
		System.out.println(result);
	}
}
