package decorate;

public interface IDecorate {

	public abstract String getParameter(String param);

}