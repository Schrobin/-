package decorate;

import java.io.UnsupportedEncodingException;

public class Decorate implements IDecorate {
	
	IDecorate old;
	public Decorate(IDecorate old){
		this.old = old;
	}

	public String getParameter(String param) {
		String a = old.getParameter(param);
		String result = null;
		try {
			byte[] array = a.getBytes("iso-8859-1");
			result = new String(array,"utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		return result;
	}

}
