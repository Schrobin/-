package alldao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import util.DBUtil;


public class DaoSupportDbutils<T> {
	public void executeUpdate(String sql, Object[] array) {
		Connection conn = DBUtil.getConnection();
		QueryRunner runner = new QueryRunner();
		try {
			runner.update(conn, sql, array);
		} catch (SQLException e) {
//			e.printStackTrace();
			throw new RuntimeException(e.getMessage(),e);
		} finally {
			DBUtil.closeConn(conn);
		}
	}

	public T queryBean(String sql, Object[] array, Class<T> clazz) {
		Connection conn = DBUtil.getConnection();
		QueryRunner runner = new QueryRunner();
		T bean = null;
		try {
			bean = runner.query(conn, sql, new BeanHandler<T>(clazz), array);
		} catch (SQLException e) {
//			e.printStackTrace();
			throw new RuntimeException(e.getMessage(),e);
		} finally {
			DBUtil.closeConn(conn);
		}
		return bean;
	}

	public List<T> queryList(String sql, Class<T> clazz) {
		Connection conn = DBUtil.getConnection();
		QueryRunner runner = new QueryRunner();
		List<T> list = null;
		try {
			list = runner.query(conn, sql, new BeanListHandler<T>(clazz));
		} catch (SQLException e) {
//			e.printStackTrace();
			throw new RuntimeException(e.getMessage(),e);
		} finally {
			DBUtil.closeConn(conn);
		}
		return list;
	}
	public List<T> queryList(String sql, Class<T> clazz,Object[] array) {
		Connection conn = DBUtil.getConnection();
		QueryRunner runner = new QueryRunner();
		List<T> list = null;
		try {
			list = runner.query(conn, sql, new BeanListHandler<T>(clazz),array);
		} catch (SQLException e) {
//			e.printStackTrace();
			throw new RuntimeException(e.getMessage(),e);
		} finally {
			DBUtil.closeConn(conn);
		}
		return list;
	}
}
