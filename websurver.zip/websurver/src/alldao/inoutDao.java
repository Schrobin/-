package alldao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DBUtil;

import allbean.inoutBean;
import allbean.PageBean;


public class inoutDao {
	DaoSupportDbutils<inoutBean> support = new DaoSupportDbutils<inoutBean>();
	public List<inoutBean> getAllCars() {
		String sql = "select * from tr_inout";
		return support.queryList(sql, inoutBean.class);
	}
	public List<inoutBean> getAllCars(String c_name,String c_num,String c_hn,String c_telnum,String c_date) {
		String sql = "select * from tr_inout where 1=1 ";
		List<String> list = new ArrayList<String>();
		if(c_name!=null&&!"".equals(c_name)){
			sql += " and c_name like ?";
			list.add("%"+c_name+"%");
		}
		if(c_num!=null&&!"".equals(c_num)){
			sql += " and c_num like ?";
			list.add("%"+c_num+"%");
		}
		if(c_hn!=null&&!"".equals(c_hn)){
			sql += " and c_hn like ?";
			list.add("%"+c_hn+"%");
		}
		if(c_telnum!=null&&!"".equals(c_telnum)){
			sql += " and c_telnum like ?";
			list.add("%"+c_telnum+"%");
		}
		if(c_date!=null&&!"".equals(c_date)){
			sql += " and c_date like ?";
			list.add("%"+c_date+"%");
		}
		Object[] array = list.toArray();
		return support.queryList(sql, inoutBean.class,array);
	}

	public List<inoutBean> getAllCars(String c_name,String c_num,String c_hn,String c_telnum,String c_date,int page) {
		int begin = PageBean.getBegin(page);
		int end = PageBean.getEnd(page);
		
		String sql = "select * from (select inner2.*,rownum num2 from (  select * from tr_inout where 1=1 ";
		List<Object> list = new ArrayList<Object>();
		if(c_name!=null&&!"".equals(c_name)){
			sql += " and c_name like ?";
			list.add("%"+c_name+"%");
		}
		if(c_num!=null&&!"".equals(c_num)){
			sql += " and c_num like ?";
			list.add("%"+c_num+"%");
		}
		if(c_hn!=null&&!"".equals(c_hn)){
			sql += " and c_hn like ?";
			list.add("%"+c_hn+"%");
		}
		if(c_telnum!=null&&!"".equals(c_telnum)){
			sql += " and c_telnum like ?";
			list.add("%"+c_telnum+"%");
		}
		if(c_date!=null&&!"".equals(c_date)){
			sql += " and c_date like ?";
			list.add("%"+c_date+"%");
		}
		sql += ") inner2 where rownum<=? ";
		sql += ") outter where num2>=?";
		list.add(end);
		list.add(begin);
		Object[] array = list.toArray();
		return support.queryList(sql, inoutBean.class,array);
	}

	public int getTotalCount(String c_name,String c_num){
		String sql = "select count(*) from tr_inout where 1=1";
		if(c_name!=null&&!"".equals(c_name)){
			sql+=" and c_name like '%"+c_name+"%'";
		}
		if(c_num!=null&&!"".equals(c_num)){
			sql+=" and c_num like '%"+c_num+"%'";
		}
		Connection conn = DBUtil.getConnection();
		ResultSet rs = null;
		PreparedStatement pstmt =null;
		int count = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			count = rs.getInt(1);
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage(),e);
		}finally{
			DBUtil.closeAll(conn, pstmt, rs);
		}
		
		return count;
	}

	public void addCar(String c_name,String c_num,String c_hn,String c_telnum,String c_date){
		//String sql = "insert into tr_inout(c_id,c_name,c_num,c_hn,c_telnum,c_date)values(seq_car.nextval,?,?,?,?,?)";
		String sql = "insert into tr_inout(c_name,c_num,c_hn,c_telnum,c_date)values(?,?,?,?,?)";
		Object[] array = {c_name,c_num,c_hn,c_telnum,c_date};
		support.executeUpdate(sql, array);
	}

	public void deleteCar(String c_id){
		String sql = "delete from tr_inout where c_id =?";
		Object[] array = {c_id};
		support.executeUpdate(sql, array);
	}

	public inoutBean getCarByBean(String c_id){
		String sql = "select c_name,c_num,c_hn,c_telnum,c_date,c_id from tr_inout where c_id=?";
		Object[] array = {c_id};
		return support.queryBean(sql, array, inoutBean.class);
	}
	public int getTotleCount(){
		String sql = "select count(*)from tr_inout";
		Connection conn = DBUtil.getConnection();
		int count = 0;
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			count = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBUtil.closeConn(conn);
		}
		return count;
		
	}

	public void updateCar(inoutBean bean){
		String sql = "update tr_inout set c_name=?,c_num=?,c_hn=?,c_telnum=?,c_date=? where c_id=?";
		Object[] array = {bean.getC_name(),bean.getC_num(),bean.getC_hn(),bean.getC_telnum(),bean.getC_date(),bean.getC_id()};
		support.executeUpdate(sql, array);
	}
	public List<inoutBean> getCarByPage(int page){
		int pageCount=10;
		int begain = page*pageCount-10;
		int end = page*pageCount;
		String sql = "select * from(select inner2.*,rownum num2 from(select*from tr_inout order by c_id desc)inner2 where rownum<=?)where num2>=?";
		Object[] array = {end,begain};
		return support.queryList(sql, inoutBean.class,array);
		
	}
	
}

