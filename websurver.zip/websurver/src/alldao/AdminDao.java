package alldao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DBUtil;

import allbean.AdminBean;




public class AdminDao {
	
	DaoSupportDbutils<AdminBean> support = new DaoSupportDbutils<AdminBean>();
	/**
	 * 得到所有admin信息
	 * @return
	 */
	public List<AdminBean> getAllAdmin(){
		String sql="select * from tr_admin order by ad_id";
		return support.queryList(sql, AdminBean.class);
	}
	public List<AdminBean> getAllAdminY(){
		String sql="select * from tr_admin where ad_role='用户' order by ad_id";
		return support.queryList(sql, AdminBean.class);
	}
	public List<AdminBean> getAllCarsYH(String ad_name) {
		String sql = "select * from tr_admin where ad_role='用户' ";
		List<String> list = new ArrayList<String>();
		if(ad_name!=null&&!"".equals(ad_name)){
			sql += " and ad_name like ?";
			list.add("%"+ad_name+"%");
		}
		sql +="order by ad_id";
		Object[] array = list.toArray();
		return support.queryList(sql, AdminBean.class,array);
	}
	public List<AdminBean> getAllCarsG(String ad_name,String ad_role) {
		String sql = "select * from tr_admin where 1=1 ";
		List<String> list = new ArrayList<String>();
		if(ad_name!=null&&!"".equals(ad_name)){
			sql += " and ad_name like ?";
			list.add("%"+ad_name+"%");
		}
		if(ad_role!=null&&!"".equals(ad_role)){
			sql += " and ad_role like ?";
			list.add("%"+ad_role+"%");
		}
		sql +="order by ad_id";
		Object[] array = list.toArray();
		return support.queryList(sql, AdminBean.class,array);
	}
	/**
	 * 添加admin信息
	 */
	public void addAdmin(AdminBean bean){
		String sql = "insert into tr_admin (ad_name,ad_pwd,ad_role) values(?,?,?)";
		Object[] array = {bean.getAd_name(),bean.getAd_pwd(),bean.getAd_role()};
		support.executeUpdate(sql, array);
	}
	public void addAdmin1(AdminBean bean){
		String sql = "insert into tr_admin (ad_name,ad_pwd,ad_role,ad_cl,ad_sex,ad_tf) values(?,?,?,?,?,?)";
		Object[] array = {bean.getAd_name(),bean.getAd_pwd(),bean.getAd_role(),bean.getAd_cl(),bean.getAd_sex(),bean.getAd_tf()};
		support.executeUpdate(sql, array);
	}
	/**
	 * 删除admin信息
	 * @param ad_id 管理员ID
	 */
	public void deleteAdmin(String ad_id){
		String sql = "delete from tr_admin where ad_id =?";
		Object[] array = {ad_id};
		support.executeUpdate(sql, array);
	}
	/**
	 * 得到某条admin信息
	 * @param ad_id adminID
	 * @return bean对象
	 */
	public AdminBean getAdminByBeanY(String ad_id){
		String sql = "select ad_name,ad_pwd,ad_role,ad_cl,ad_sex,ad_tf,ad_id from tr_admin where ad_id=?";
		Object[] array = {ad_id};
		return support.queryBean(sql,array,AdminBean.class);
	}
	public AdminBean getAdminByBean(String ad_id){
		String sql = "select ad_name,ad_pwd,ad_role,ad_id from tr_admin where ad_id=?";
		Object[] array = {ad_id};
		return support.queryBean(sql,array,AdminBean.class);
	}
	public AdminBean getAdminByBeannew(String ad_name){
		String sql = "select ad_name,ad_pwd,ad_role,ad_cl,ad_sex,ad_tf from tr_admin where ad_name=?";
		Object[] array = {ad_name};
		return support.queryBean(sql,array,AdminBean.class);
	}
	/**
	 * 根据查询条件获取总条数
	 * @param ad_name
	 * @param ad_role
	 * @return
	 */
	public int getTotalCountYH(String ad_name){
		String sql = "select count(*) from tr_admin where ad_role='用户'";
		if(ad_name!=null&&!"".equals(ad_name)){
			sql+=" and ad_name like '%"+ad_name+"%'";
		}
		Connection conn = DBUtil.getConnection();
		ResultSet rs = null;
		PreparedStatement pstmt =null;
		int count = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			count = rs.getInt(1);
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage(),e);
		}finally{
			DBUtil.closeAll(conn, pstmt, rs);
		}
		
		return count;
	}
	public int getTotalCount(String ad_name,String ad_role){
		String sql = "select count(*) from tr_admin where 1=1";
		if(ad_name!=null&&!"".equals(ad_name)){
			sql+=" and ad_name like '%"+ad_name+"%'";
		}
		if(ad_role!=null&&!"".equals(ad_role)){
			sql+=" and ad_role like '%"+ad_role+"%'";
		}
		Connection conn = DBUtil.getConnection();
		ResultSet rs = null;
		PreparedStatement pstmt =null;
		int count = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			count = rs.getInt(1);
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage(),e);
		}finally{
			DBUtil.closeAll(conn, pstmt, rs);
		}
		
		return count;
	}
	/**
	 * 更新admin
	 * @param bean
	 */
	public void updateAdminC(AdminBean bean){
		String sql = "update tr_admin set ad_tf=? where ad_id=?";
		Object[] array = {bean.getAd_tf(),bean.getAd_id()};
		support.executeUpdate(sql, array);
	}
	public void updateAdmin(AdminBean bean){
		String sql = "update tr_admin set ad_name=?,ad_pwd=?,ad_role=? where ad_id=?";
		Object[] array = {bean.getAd_name(),bean.getAd_pwd(),bean.getAd_role(),bean.getAd_id()};
		support.executeUpdate(sql, array);
	}
	public void updateAdminRun(AdminBean run){
		String sql = "update tr_admin set ad_tf=? where ad_id=?";
		Object[] array = {run.getAd_tf(),run.getAd_id()};
		support.executeUpdate(sql, array);
	}
	public void updateAdminY(AdminBean bean){
		String sql = "update tr_admin set ad_name=?,ad_pwd=?,ad_role=?,ad_cl=?,ad_sex=? where ad_id=?";
		Object[] array = {bean.getAd_name(),bean.getAd_pwd(),bean.getAd_role(),bean.getAd_cl(),bean.getAd_sex(),bean.getAd_id()};
		support.executeUpdate(sql, array);
	}
	public void updateAdminnew(AdminBean bean){
		String sql = "update tr_admin set ad_pwd=?,ad_role=?,ad_cl=?,ad_sex=?,ad_tf=? where ad_name=?";
		Object[] array = {bean.getAd_pwd(),bean.getAd_role(),bean.getAd_cl(),bean.getAd_sex(),bean.getAd_tf(),bean.getAd_name()};
		support.executeUpdate(sql, array);
	}
	public List<AdminBean> getAdminByPage(int page){
		//1 1-10
		//2 11-20
		int pageCount=10;
		int begain = page*pageCount-10;
		int end = page*pageCount;
		//String sql = "select*from(select inner2.*,rownum num2 from(select*from tr_admin order by ad_id desc)inner2 where rownum<=?)where num2>=?";
		String sql = "select * from tr_admin order by ad_id desc limit ?,? ";
		Object[] array = {end,begain};
		return support.queryList(sql, AdminBean.class,array);
		
	}
	public int getTotleCount(){
		String sql = "select count(*)from tr_admin";
		Connection conn = DBUtil.getConnection();
		int count = 0;
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			count = rs.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.closeConn(conn);
		}
		return count;
		
	}
	public int getTotleCountY(String ad_name){
		String sql = "select count(*)from tr_admin where ad_role='用户'";
		if(ad_name!=null&&!"".equals(ad_name)){
			sql+=" and ad_name like '%"+ad_name+"%'";
		}
		Connection conn = DBUtil.getConnection();
		ResultSet rs = null;
		PreparedStatement pstmt =null;
		int count = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			count = rs.getInt(1);
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage(),e);
		}finally{
			DBUtil.closeAll(conn, pstmt, rs);
		}
		
		return count;
	}
	public int getTotleCountG(String ad_name,String ad_role){
		String sql = "select count(*)from tr_admin where 1=1";
		if(ad_name!=null&&!"".equals(ad_name)){
			sql+=" and ad_name like '%"+ad_name+"%'";
		}
		if(ad_role!=null&&!"".equals(ad_role)){
			sql+=" and ad_role like '%"+ad_role+"%'";
		}
		Connection conn = DBUtil.getConnection();
		ResultSet rs = null;
		PreparedStatement pstmt =null;
		int count = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			count = rs.getInt(1);
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage(),e);
		}finally{
			DBUtil.closeAll(conn, pstmt, rs);
		}
		
		return count;
	}
	/**
	 * 得到所有admin信息
	 * @return
	 */
	public List<AdminBean> getAllAdmins(String ad_name,String ad_role) {
		String sql = "select * from tr_admin where 1=1 ";
		List<String> list = new ArrayList<String>();
		if(ad_name!=null&&!"".equals(ad_name)){
			sql += " and ad_name like ?";
			list.add("%"+ad_name+"%");
		}
		if(ad_role!=null&&!"".equals(ad_role)){
			sql += " and ad_role like ?";
			list.add("%"+ad_role+"%");
		}
		Object[] array = list.toArray();
		return support.queryList(sql, AdminBean.class,array);
	}
	
	public AdminBean getAdmin(String username,String pwd,String ad_role){
		String sql = "select * from tr_admin where ad_name=? and ad_pwd=? and ad_role=?";
		Object[] array = {username,pwd,ad_role};
		return support.queryBean(sql, array, AdminBean.class);
	}
	public AdminBean getAdmin(String ad_name,String ad_sex){
		String sql = "select * from tr_admin where ad_name=? and ad_sex=?";
		Object[] array = {ad_name,ad_sex};
		return support.queryBean(sql, array, AdminBean.class);
	}
}
