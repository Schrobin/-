package allbean;

public class PageBean {
	public static final int PAGECOUNT = 10;
	/**
	 * 根据第几页计算条数
	 * @param page
	 * @return
	 */
	public static int getBegin(int page){
		return page = page*PAGECOUNT-PAGECOUNT-1;
	}
	/**
	 * 根据第几页计算结束条数
	 * @param page
	 * @return
	 */
	public static int getEnd(int page){
		return page = page*PAGECOUNT;
	}
	/**
	 * 得到总页数
	 * @param totalCount
	 * @return
	 */
	public static int getTotalPage(int totalCount){
		return (int)Math.ceil((double)totalCount/PAGECOUNT);
	}
}
