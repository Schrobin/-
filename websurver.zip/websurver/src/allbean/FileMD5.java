package allbean;

public class FileMD5 {
	private String originalMD5;

	public String getOriginalMD5() {
		return originalMD5;
	}

	public void setOriginalMD5(String originalMD5) {
		this.originalMD5 = originalMD5;
	}

}
