package allbean;

public class inoutBean {

	int c_id;
    String c_name;
	
	String c_num;
	
	String c_hn;
	
	String c_telnum;
	
	String c_date;

    public int getC_id() {
		return c_id;
	}

	public void setC_id(int c_id) {
		this.c_id = c_id;
	}

	public String getC_name() {
		return c_name;
	}

	public void setC_name(String c_name) {
		this.c_name = c_name;
	}

	public String getC_num() {
		return c_num;
	}

	public void setC_num(String c_num) {
		this.c_num = c_num;
	}

	public String getC_hn() {
		return c_hn;
	}

	public void setC_hn(String c_hn) {
		this.c_hn = c_hn;
	}

	public String getC_telnum() {
		return c_telnum;
	}

	public void setC_telnum(String c_telnum) {
		this.c_telnum = c_telnum;
	}

	public String getC_date() {
		return c_date;
	}

	public void setC_date(String c_date) {
		this.c_date = c_date;
	}

	
	
	
	
}
