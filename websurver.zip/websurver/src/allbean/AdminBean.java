package allbean;

public class AdminBean {
	/**
	 * admin id
	 */
	private int ad_id;
	private String ad_name;
	private String ad_pwd;
	private String ad_role;
	private String ad_cl;
	private String ad_sex;
	private String ad_tf;
	public String getAd_cl() {
		return ad_cl;
	}
	public void setAd_cl(String ad_cl) {
		this.ad_cl = ad_cl;
	}
	public String getAd_sex() {
		return ad_sex;
	}
	public void setAd_sex(String ad_sex) {
		this.ad_sex = ad_sex;
	}
	public String getAd_tf() {
		return ad_tf;
	}
	public void setAd_tf(String ad_tf) {
		this.ad_tf = ad_tf;
	}
	public int getAd_id() {
		return ad_id;
	}
	public void setAd_id(int ad_id) {
		this.ad_id = ad_id;
	}
	public String getAd_name() {
		return ad_name;
	}
	public void setAd_name(String ad_name) {
		this.ad_name = ad_name;
	}
	public String getAd_pwd() {
		return ad_pwd;
	}
	public void setAd_pwd(String ad_pwd) {
		this.ad_pwd = ad_pwd;
	}
	public String getAd_role() {
		return ad_role;
	}
	public void setAd_role(String ad_role) {
		this.ad_role = ad_role;
	}
}
