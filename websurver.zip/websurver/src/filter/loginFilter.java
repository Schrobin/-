package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class loginFilter implements Filter{

	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
			//判断是否是登录状态，如果是登录状态，访问目标资源，如果不是登录状态，到登录界面
		HttpServletRequest req = (HttpServletRequest)request;
		//1得到请求内容，如果是LoginServlet应该放过
		String url=req.getRequestURI().toString();
		if(url.indexOf("LoginServlet")!=-1||url.indexOf("css")!=-1||url.indexOf("images")!=-1||url.indexOf("index.jsp")!=-1){
			//放过
			chain.doFilter(request, response);
		}else{
			//2判断是否登录
			HttpSession session = req.getSession();
			String username=(String)session.getAttribute("username");
			//没有登录
			if(username==null){
				request.setAttribute("errorMsg","对不起，没有登录");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}else{
				//登录状态
				//访问目标资源或者下一个过滤器
				chain.doFilter(request, response);
			}
			
		}
		HttpServletRequest res = (HttpServletRequest)response;
		
	}

	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}
	
}
