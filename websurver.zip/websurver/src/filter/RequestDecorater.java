package filter;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class RequestDecorater extends HttpServletRequestWrapper{
	
	public RequestDecorater(HttpServletRequest request){
		super(request);
	}

	public String getParameter(String arg0) {
		String result = this.getRequest().getParameter(arg0);
		if(result!=null&&!"".equals(result)){
			try {
				byte[] array = result.getBytes("iso-8859-1");
				result = new String(array,"utf-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
	  
}
