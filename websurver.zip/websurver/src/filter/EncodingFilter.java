package filter;
import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;


public class EncodingFilter implements Filter{

	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// post方式
		HttpServletRequest req = (HttpServletRequest)request;
		String method = req.getMethod();
		if("POST".equals(method)){
		request.setCharacterEncoding("utf-8");
		chain.doFilter(request, response);
		}else{
		//增强request,getParameter()方法
		//如何动态修改某个对象的方法，装饰设计模式
			RequestDecorater dec = new RequestDecorater(req);
			chain.doFilter(dec, response);
		}
		}

	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}
		
}
